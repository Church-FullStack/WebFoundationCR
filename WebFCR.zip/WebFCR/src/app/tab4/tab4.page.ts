import { Component, OnInit } from '@angular/core';
import { Message } from '../models/message';
import { DataService } from '../services/data.service';
import { SharedService } from '../services/shared.service';
import { Friend } from '../models/friend';
import { Postshare } from '../models/share';

@Component({
  selector: 'app-tab4',
  templateUrl: './tab4.page.html',
  styleUrls: ['./tab4.page.scss'],
})
export class Tab4Page{

  model: Postshare = new Postshare();

  myFriends: Friend[] = [];
  
  constructor( private shared: SharedService, private data: DataService) {
      this.data.getAllFriends().subscribe(list => {
        this.myFriends = list.filter((friend) => friend.friendOf == this.shared.userName)
        });
      
    
  }
  
  share() {
    this.model.from = this.shared.userName;
    this.data.saveShare(this.model);
    console.log("save", this.model);
    this.model = new Postshare();
  }
    
  }
  






