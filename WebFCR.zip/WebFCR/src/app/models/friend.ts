export class Friend {
    name: string;
    friendOf: string;
    
}