export class Message {
    text: string;
    Url: string;
    createdOn: Date;
    from: string;
    to: string;

    constructor() {
        this.createdOn = new Date();
        this.to = 'Everyone';
    }
}